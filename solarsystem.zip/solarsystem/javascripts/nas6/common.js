﻿//2015
var isIE= false;
var isOpera= false;
var isSafari= false;
var isChrome= false;
var isFireFox= false;

function ChkBrws(){
  if(window.navigator.userAgent.toLowerCase().indexOf('msie') != -1) isIE = true;
  if(window.navigator.userAgent.toLowerCase().indexOf('trident') != -1) isIE = true;
  if(window.navigator.userAgent.toLowerCase().indexOf('safari') != -1) isSafari = true;
  if(window.navigator.userAgent.toLowerCase().indexOf('chrome') != -1) isChrome = true;
  if(isChrome) isSafari = false; 
  if(window.navigator.userAgent.toLowerCase().indexOf('firefox') != -1) isFireFox = true; 
  if(window.navigator.userAgent.toLowerCase().indexOf('opr') != -1) isOpera = true;
  if(isOpera) { isChrome = false; isSafari = false; }
}

function isZoom(){
  ChkBrws();
  var z = -1.0;
  if(isIE) z = (screen.deviceXDPI / 96.0);
  else z = (window.devicePixelRatio);
  return z;
}

function TextContent(element,value){
  var content = element.textContent;
  if (value === undefined) {
    if (content !== undefined) return content;
    else return element.innerText;
  }
  else {
    if (content !== undefined) element.textContent = value;
    else element.innerText = value;
  }
}

function getScrollPos(){
  var obj = new Object();
  var x1 = x2 = x3 = 0;
  var y1 = y2 = y3 = 0;
  if (document.documentElement) {
    x1 = document.documentElement.scrollLeft || 0;
    y1 = document.documentElement.scrollTop || 0;
  }
  if (document.body) {
    x2 = document.body.scrollLeft || 0;
    y2 = document.body.scrollTop || 0;
  }
  x3 = window.scrollX || 0;
  y3 = window.scrollY || 0;
  obj.x = Math.max(x1, Math.max(x2, x3));
  obj.y = Math.max(y1, Math.max(y2, y3));
  return obj;
}

function getScreenSize() {
  ChkBrws();
  var obj = new Object();
  if (!isSafari && !isOpera) {
    obj.x = document.documentElement.clientWidth || document.body.clientWidth || document.body.scrollWidth;
    obj.y = document.documentElement.clientHeight || document.body.clientHeight || document.body.scrollHeight;
  } else {
    obj.x = window.innerWidth;
    obj.y = window.innerHeight;
  }
  obj.mx = parseInt((obj.x)/2);
  obj.my = parseInt((obj.y)/2);
  return obj;
}

function getScrollPosition() {
  var obj = new Object();
  obj.x = document.documentElement.scrollLeft || document.body.scrollLeft;
  obj.y = document.documentElement.scrollTop || document.body.scrollTop;
  return obj;
}

function ElmReqFullscreen(elm) {
  var list = [
    "requestFullscreen",
    "webkitRequestFullScreen",
    "mozRequestFullScreen",
    "msRequestFullscreen"
  ];
  var i;
  var num = list.length;
  for(i = 0; i < num; i++) {
    if(elm[list[i]]) {
      elm[list[i]]();
      return true;
    }
  }
  return false;
}

function DocExitFullscreen(doc) {
  var list = [
    "exitFullscreen",
    "webkitExitFullscreen",
    "mozCancelFullScreen",
    "msExitFullscreen"
  ];
  var i;
  var num = list.length;
  for(i = 0; i < num; i++) {
    if(doc[list[i]]) {
      doc[list[i]]();
      return true;
    }
  }
  return false;
}

function Rand(min, max){
  if(max < min){
    var t = min;
    min = max;
    max = t;
  }
  return (Math.random() * (max - min) + min)
}

function RandSqr(min, max){
  if(max < min){
    var t = min;
    min = max;
    max = t;
  }
  var r = Math.random();
  return (r * r * (max - min) + min)
}

function RandSqr2(min, max){
  if(max < min){
    var t = min;
    min = max;
    max = t;
  }
  var r1 = Math.random();
  var r2 = Math.random();
  return (r1 * r2 * (max - min) + min)
}

//read CSV //CSV読み込み
function readCSV(filename,analyzefunc,donefunc){
  var afunc = new Function("param", "return " + analyzefunc + "(param)");   
  var dfunc = new Function("param", "return " + donefunc + "(param)");   
  var httpObj = new XMLHttpRequest();
  res = "";
  httpObj.open("GET", filename, true);
  httpObj.onreadystatechange = function() {
    if (httpObj.readyState == 4) {
      if(httpObj.status == 0){
        alert("Error:connect");
      }
      else if((200 <= httpObj.status && httpObj.status < 300) || (httpObj.status == 304)) {
        res = httpObj.responseText;
        res = afunc(res);
        dfunc(res);
        return res;
      }
      else {
        alert("Error:others");
      }
    }
  }
  httpObj.send(null);
  return true;
}

//analyze CSV //CSV解析
function analyzeCSV(res) {
  var ares = new Array();
  var line;
  if (res.match(/\r/))     line = res.split("\r\n");
  else                     line = res.split("\n");

  var linenum = line.length;
  for (var i = 0; i < linenum; i++) ares[i] = new Array();
  var k = 0;
  var maxcol = 0;
  for (i = 0; i < linenum; i++) {
    if(line[i][0] == '#') {k++; continue;} //skip comment out//コメントアウトはスキップ
    line[i] = line[i].replace( /\t/g,"");
    line[i] = line[i].replace( /\s/g,"");
    var col = line[i].split(",");
    var colnum = col.length;
    for (var j = 0; j < colnum; j++) ares[i - k][j] = col[j];
    if (colnum > maxcol) maxcol = colnum;
  }
  ares.length = linenum - k;
  return ares;
}

//ex//使用例：readCSV('filename', 'analyzeCSV', 'donefunc');

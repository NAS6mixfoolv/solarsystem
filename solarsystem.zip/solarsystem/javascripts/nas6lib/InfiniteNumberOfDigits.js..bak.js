﻿//Programed by NAS6
//InfiniteNumberOfDigits.js

class N6LSTRNUM_IND {

  constructor() {
    this.type = "N6LSTRNUM_IND";
    this.num = "";
    this.base = 10;
    return this;
  }


  function createSTRNUM_IND(num,base,inputbase) {
    this.type = "N6LSTRNUM_IND";
    this.num = "";
    this.base = 10;
    if(base != undefined){
      this.base = base;
    }

    if(isNumber(num) == true){
      this.num = num2str_base(num, base);
      return this;
    }
    else if(typeof num === "string" || num instanceof String){

      //var ibase = base;
      //if(inputbase != undefined){
      //  ibase = inputbase;
      //}

      return this;
    }
    else { return null; }
    return this;
  }

  function getBaseLog(x, y){
    return Math.log(y) / Math.log(x);
  }

  function reverseString(str) {
    var splitString = str.split("");
    var reverseArray = splitString.reverse(); 
    var joinArray = reverseArray.join("");
    return joinArray;
  }

  function num2str_base(num, base){
    var ret = "";

    var tmp = "";
    var itmp = "";
    var dtmp = "";
    var intnum = parseInt(num);
    var decnum = num - intnum;
    var intdig = getBaseLog(base, intnum);
    var decdig = getBaseLog(base, decnum);
    var i,j,k;

    k = base;
    j = intnum % k;

    if(base <= 10){
      tmp += "0" + j;
    }
    else if(base <= 10 + 26){
      if(10 <= j){
        tmp += "A" + (j - 10);
      }
      else{
        tmp += "0" + j;
      }
    }

    for(i = 1; i < intdig; i++){
      k *= base;

      j = intnum % k;

      if(base <= 10){
        tmp += "0" + j;
      }
      else if(base <= 10 + 26){
        if(10 <= j){
          tmp += "A" + (j - 10);
        }
        else{
          tmp += "0" + j;
        }
      }
    }
    itmp = reverseString(tmp);

    k = 1 / base;
    j = intnum % k;

    if(base <= 10){
      tmp += "0" + j;
    }
    else if(base <= 10 + 26){
      if(10 <= j){
        tmp += "A" + (j - 10);
      }
      else{
        tmp += "0" + j;
      }
    }

    for(i = 1; i < decdig; i++){
      k /= base;

      j = decnum % k;

      if(base <= 10){
        tmp += "0" + j;
      }
      else if(base <= 10 + 26){
        if(10 <= j){
          tmp += "A" + (j - 10);
        }
        else{
          tmp += "0" + j;
        }
      }
    }
    dtmp = tmp;
    ret = itmp + dtmp;

    return ret;

  }
};

